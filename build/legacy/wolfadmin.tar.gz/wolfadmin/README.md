# WolfAdmin
WolfAdmin is a Lua module for Wolfenstein: Enemy Territory servers.

* Website [http://dev.timosmit.com/wolfadmin](http://dev.timosmit.com/wolfadmin)
* Download [http://dev.timosmit.com/wolfadmin/download.html](http://dev.timosmit.com/wolfadmin/download.html)
* Installation instructions [http://dev.timosmit.com/wolfadmin/setup.html](http://dev.timosmit.com/wolfadmin/setup.html)
* Configuration documentation [http://dev.timosmit.com/wolfadmin/configuration.html](http://dev.timosmit.com/wolfadmin/configuration.html)
* Issues [http://dev.timosmit.com/bugtracker/?project_id=1](http://dev.timosmit.com/bugtracker/?project_id=1)
* Repository [https://github.com/timosmit/wolfadmin](https://github.com/timosmit/wolfadmin)

DEPENDENCIES
============
* **luasql.sqlite3** and/or **luasql.mysql**
* **lua-toml**

LICENSE
============
[GNU General Public License 3](http://www.gnu.org/licenses/gpl-3.0.html)
